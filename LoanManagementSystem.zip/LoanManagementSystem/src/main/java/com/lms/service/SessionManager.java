package com.lms.service;

public class SessionManager {

	public static Long sessionId = null;
	public static String sessionName = null;
	public static Long userCount = null;
	public static String accountType = null;
	public static String profilePic = null;
}
